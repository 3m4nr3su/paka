package com.example.catapi;
public class CatImage {
	private String url;

    public CatImage(String url) {
        this.url = url;
    }

    public String URL() {
        return url;
    }

}
