package com.example.catapi;

import java.io.IOException;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Path;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

@Path("/Paka")
public class Paka extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String SEARCH_TERM = "cat";
	private static final String SEARCH_COLOR_PARAM = "color";
	private static final String USER_AGENT = "Mozilla/5.0";

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String searchColor = request.getParameter(SEARCH_COLOR_PARAM);
		String searchTerm = SEARCH_TERM;
		if (searchColor != null && !searchColor.isEmpty()) {
			searchTerm += " " + searchColor;
		}

		// Build the search URL
		String searchUrl = "https://www.google.com/search?q=" + URLEncoder.encode(searchTerm, "UTF-8")
				+ "&source=lnms&tbm=isch&tbs=isz:lt,islt:qsvga";
		System.out.println("Page URL: " + searchUrl);

		// Fetch the search results page
		Document doc = Jsoup.connect(searchUrl).userAgent(USER_AGENT).get();
		// Debug statement to print out the HTML content of the search results page
		//System.out.println("Search Results HTML: " + doc.html());

		// Select the first search result image
		Element imgElement = doc.select("img.yWs4tf").first();

		if (imgElement != null) {
		// Extract the image URL
		String selectedURL = imgElement.attr("src");
		System.out.println("Image URL: " + selectedURL);

		// Build the HTML response
		String html = "<html><body style=\"background-color: yellow;\"><center><img src=\"" + selectedURL
				+ "\"/></center></body></html>";

		// Set the response content type to HTML
		response.setContentType("text/html");

		// Write the HTML response to the output stream
		response.getWriter().write(html);
	} else {
	    // Handle the case where no img element is found
	    String html = "<html><body><h1>No image found</h1></body></html>";
	    response.setContentType("text/html");
	    response.getWriter().write(html);
	}}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
